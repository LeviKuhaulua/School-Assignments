Levi Kuhaulua
Homework #5 


#1: 190

#3: 
Average Execution Time 
1 thread: 29.361 seconds avg
2 threads: 16.446 seconds avg
3 threads: 17.077 seconds avg

q1: 29.361 / 16.446 = 1.7853x faster 
q2: 12 cores